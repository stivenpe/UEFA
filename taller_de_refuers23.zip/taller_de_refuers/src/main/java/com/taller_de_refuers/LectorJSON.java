package com.taller_de_refuers;


import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.util.List;


public class LectorJSON {
    public static List<Equipo> leerEquiposDesdeJSON(String rutaArchivo) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        RespuestaEquipos respuesta = objectMapper.readValue(new File(rutaArchivo), RespuestaEquipos.class);
        return respuesta.getEquipos();
    }
}