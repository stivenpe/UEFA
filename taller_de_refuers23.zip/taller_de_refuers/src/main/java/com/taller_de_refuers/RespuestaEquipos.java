package com.taller_de_refuers;

import java.util.List;

public class RespuestaEquipos {
    private List<Equipo> equipos;

    // Getter y Setter
    public List<Equipo> getEquipos() {
        return equipos;
    }

    public void setEquipos(List<Equipo> equipos) {
        this.equipos = equipos;
    }
}
