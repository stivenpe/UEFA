package com.taller_de_refuers;


import java.util.List;


public class Equipo {
    private int id; // Añade este campo
    private String name; // Cambia "nombre" a "name"
    private String yearfoundation; // Cambia "anioFundacion" a "yearfoundation"
    private String coach; // Entrenador
    private List<Jugador> players; // Jugadores
    private List<Estadisticas> statistics; // Estadísticas

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getYearfoundation() {
        return yearfoundation;
    }

    public void setYearfoundation(String yearfoundation) {
        this.yearfoundation = yearfoundation;
    }

    public String getCoach() {
        return coach;
    }

    public void setCoach(String coach) {
        this.coach = coach;
    }

    public List<Jugador> getPlayers() {
        return players;
    }

    public void setPlayers(List<Jugador> players) {
        this.players = players;
    }

    public List<Estadisticas> getStatistics() {
        return statistics;
    }

    public void setStatistics(List<Estadisticas> statistics) {
        this.statistics = statistics;
    }
}