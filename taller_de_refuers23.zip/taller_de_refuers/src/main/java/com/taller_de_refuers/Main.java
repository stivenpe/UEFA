package com.taller_de_refuers;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            // Leer el archivo JSON
            List<Equipo> equipos = LectorJSON.leerEquiposDesdeJSON("src/main/resources/equipo.json");

            // Crear el procesador
            ProcesadorEquipos procesador = new ProcesadorEquipos(equipos);

            // Inicializar el scanner para la entrada del usuario
            Scanner scanner = new Scanner(System.in);
            int opcion;

            do {
                // Mostrar el menú de opciones
                System.out.println("\n--- MENÚ PRINCIPAL ---");
                System.out.println("1. Equipos fundados después del año 2000");
                System.out.println("2. Imprimir nombres de entrenadores");
                System.out.println("3. Promedio de edad de jugadores por equipo");
                System.out.println("0. Salir");
                System.out.print("Ingrese una opción: ");

                // Leer la opción ingresada por el usuario
                opcion = scanner.nextInt();

                // Procesar la opción seleccionada
                switch (opcion) {
                    case 1:
                        procesador.equiposFundadosDespuesDe2000();
                        break;
                    case 2:
                        procesador.imprimirNombresEntrenadores();
                        break;
                    case 3:
                        procesador.promedioEdadJugadoresPorEquipo();
                        break;
                    case 4:
                        procesador.porterosAltos();
                        break;
                    case 5:
                        procesador.delanterosArgentinos();
                        break;
                    case 6:
                        procesador.entrenadoresConGuardiola();
                        break;
                    case 7:
                        procesador.equiposConMasDe70Puntos();
                        break;
                    case 8:
                        procesador.jugadoresMayoresDe30();
                        break;
                    case 9:
                        procesador.equiposConMasGolesAnotadosQueRecibidos();
                        break;
                    case 10:
                        procesador.jugadoresConPesoSuperiorA80kg();
                        break;
                    case 11:
                        procesador.equiposConMasDe20PartidosGanados();
                        break;
                    case 12:
                        procesador.jugadoresConDorsalMenorA10();
                        break;
                    case 13:
                        procesador.equiposConMenosDe5PartidosPerdidos();
                        break;
                    case 0:
                        System.out.println("Saliendo del programa...");
                        break;
                    default:
                        System.out.println("Opción no válida. Intente de nuevo.");
                        break;
                }

            } while (opcion != 0); // Repetir hasta que el usuario elija salir

            // Cerrar el scanner
            scanner.close();

        } catch (Exception e) {
            // Manejar errores específicos
            System.err.println("Error al procesar los datos:");
            e.printStackTrace();
        }
    }
}