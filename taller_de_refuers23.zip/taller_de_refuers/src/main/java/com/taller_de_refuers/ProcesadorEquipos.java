package com.taller_de_refuers;

import java.util.List;


public class ProcesadorEquipos {
    private List<Equipo> equipos;

    public ProcesadorEquipos(List<Equipo> equipos) {
        this.equipos = equipos;
    }

    // Reto 1: Equipos fundados después del año 2000
    public void equiposFundadosDespuesDe2000() {
        System.out.println("Equipos fundados después del año 2000:");
        equipos.stream()
                .filter(e -> Integer.parseInt(e.getYearfoundation()) > 2000) // Convertimos "yearfoundation" a entero
                .forEach(e -> System.out.println(e.getName())); // Usamos getName() en lugar de getNombre()
    }

    public void imprimirNombresEntrenadores() {
        System.out.println("Nombres de los entrenadores:");
        equipos.forEach(e -> System.out.println("- " + e.getCoach()));
    }

    // Reto 3: Jugadores mayores de 30 años
    public void jugadoresMayoresDe30() {
        System.out.println("Jugadores mayores de 30 años:");
        equipos.stream()
                .flatMap(e -> e.getPlayers().stream()) // Obtenemos todos los jugadores
                .filter(j -> Integer.parseInt(j.getAge()) > 30) // Filtramos por edad
                .forEach(j -> System.out.println(j.getName() + " (" + j.getAge() + " años)"));
    }

    // Reto 4: Porteros con altura mayor a 190 cm
    public void porterosAltos() {
        System.out.println("Porteros con altura mayor a 190 cm:");
        equipos.stream()
                .flatMap(e -> e.getPlayers().stream()) // Obtenemos todos los jugadores
                .filter(j -> j.getPosition().equalsIgnoreCase("Portero")) // Filtramos por posición "Portero"
                .filter(j -> Integer.parseInt(j.getHeight()) > 190) // Filtramos por altura
                .forEach(j -> System.out.println(j.getName() + " (" + j.getHeight() + " cm)"));
    }

    // Reto 5: Delanteros con nacionalidad argentina
    public void delanterosArgentinos() {
        System.out.println("Delanteros con nacionalidad argentina:");
        equipos.stream()
                .flatMap(e -> e.getPlayers().stream()) // Obtenemos todos los jugadores
                .filter(j -> j.getPosition().equalsIgnoreCase("Delantero")) // Filtramos por posición "Delantero"
                .filter(j -> j.getNationality().equalsIgnoreCase("Argentino")) // Filtramos por nacionalidad
                .forEach(j -> System.out.println(j.getName() + " (" + j.getNationality() + ")"));
    }

    // Reto 6: Entrenadores cuyos nombres contienen "Guardiola"
    public void entrenadoresConGuardiola() {
        System.out.println("Entrenadores cuyos nombres contienen 'Guardiola':");
        equipos.stream()
                .filter(e -> e.getCoach().toLowerCase().contains("guardiola")) // Filtramos por nombre del entrenador
                .forEach(e -> System.out.println(e.getName() + " - Entrenador: " + e.getCoach()));
    }

    public void promedioEdadJugadoresPorEquipo() {
        System.out.println("Promedio de edad de jugadores por equipo:");
        equipos.forEach(e -> {
            double promedio = e.getPlayers().stream()
                    .mapToInt(j -> Integer.parseInt(j.getAge()))
                    .average()
                    .orElse(0.0);
            System.out.println("- " + e.getName() + ": " + String.format("%.2f", promedio) + " años");
        });
    }

    public void equiposConMasDe70Puntos() {
        System.out.println("Equipos con más de 70 puntos:");
        equipos.stream()
                .filter(e -> e.getStatistics().stream()
                        .anyMatch(s -> Integer.parseInt(s.getTp()) > 70))
                .forEach(e -> System.out.println("- " + e.getName()));
    }

    public void equiposConMasGolesAnotadosQueRecibidos() {
        System.out.println("Equipos con más goles anotados que recibidos:");
        equipos.stream()
                .filter(e -> e.getStatistics().stream()
                        .anyMatch(s -> Integer.parseInt(s.getGf()) > Integer.parseInt(s.getGc())))
                .forEach(e -> System.out.println("- " + e.getName()));
    }

    public void jugadoresConPesoSuperiorA80kg() {
        System.out.println("Jugadores con peso superior a 80 kg:");
        equipos.stream()
                .flatMap(e -> e.getPlayers().stream())
                .filter(j -> Integer.parseInt(j.getWeight()) > 80)
                .forEach(j -> System.out.println("- " + j.getName() + " (" + j.getWeight() + " kg)"));
    }

    public void equiposConMasDe20PartidosGanados() {
        System.out.println("Equipos con más de 20 partidos ganados:");
        equipos.stream()
                .filter(e -> e.getStatistics().stream()
                        .anyMatch(s -> Integer.parseInt(s.getPg()) > 20))
                .forEach(e -> System.out.println("- " + e.getName()));
    }

    public void jugadoresConDorsalMenorA10() {
        System.out.println("Jugadores con dorsal menor a 10:");
        equipos.stream()
                .flatMap(e -> e.getPlayers().stream())
                .filter(j -> Integer.parseInt(j.getDorsal()) < 10)
                .forEach(j -> System.out.println("- " + j.getName() + " (Dorsal: " + j.getDorsal() + ")"));
    }

    public void equiposConMenosDe5PartidosPerdidos() {
        System.out.println("Equipos con menos de 5 partidos perdidos:");
        equipos.stream()
                .filter(e -> e.getStatistics() != null && !e.getStatistics().isEmpty())
                .filter(e -> e.getStatistics().stream()
                        .anyMatch(s -> {
                            try {
                                String pp = s.getPp();
                                return pp != null && !pp.isEmpty() && Integer.parseInt(pp) < 5;
                            } catch (NumberFormatException ex) {
                                return false; // Ignorar valores no válidos
                            }
                        }))
                .forEach(e -> System.out.println("- " + e.getName()));
    }





    // Implementa los otros retos aquí siguiendo la misma estructura...
}